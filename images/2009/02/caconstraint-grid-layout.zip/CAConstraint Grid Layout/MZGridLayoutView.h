//
//  MZGridLayoutView.h
//  CAConstraint Grid Layout
//
//  Created by Benjamin on 3/02/09.
//  Copyright 2009 Mozketo. All rights reserved.
//  http://mozketo.com
//

#import <Cocoa/Cocoa.h>
#import <QuartzCore/QuartzCore.h>

@interface MZGridLayoutView : NSView {
	CALayer* gridLayer;
}

- (void)layoutCellsInGridLayer:(CALayer *)layer;
- (void)setupPerspectiveWithX:(float)x andY:(float)y;
- (void)createCellInParentLayer:(CALayer *)parent totalColumns:(int)columns totalRows:(int)rows currentColumn:(int)column currentRow:(int)row;
- (void)constrainLayerToSuperlayer:(CALayer *)layer withScale:(float)scale;

@end
