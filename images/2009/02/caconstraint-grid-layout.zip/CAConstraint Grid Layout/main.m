//
//  main.m
//  CAConstraint Grid Layout
//
//  Created by Benjamin on 3/02/09.
//  Copyright Mozketo 2009. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
