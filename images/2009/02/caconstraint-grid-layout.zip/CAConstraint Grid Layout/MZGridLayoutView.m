//
//  MZGridLayoutView.m
//  CAConstraint Grid Layout
//
//  Created by Benjamin on 3/02/09.
//  Copyright 2009 Mozketo. All rights reserved.
//  http://mozketo.com
//
//  License: MIT http://www.opensource.org/licenses/mit-license.php

#import "MZGridLayoutView.h"

#define kDebugLayers NO

static double frandom(double start, double end) {
	double r = random();
	r /= RAND_MAX;
	r = start + r * (end-start);
	return r;
}

@implementation MZGridLayoutView

- (void)awakeFromNib {
	CALayer* rootLayer = [CALayer layer];
	rootLayer.borderWidth = (kDebugLayers == YES) ? 1.0f : 0.0f;
	self.layer = rootLayer;
	self.wantsLayer = YES;
	
	// This is the layer which will house all the little Cell Layers
	// This layer doesn't do much, and you probably don't need this
	// layer. I find it prudent not to use the rootLayer for anything, and it
	// allows for easy mass manipulation off all the cells at once if required
	// (eg you want to Translate all of them at the same time off the view)
	gridLayer = [CALayer layer];
	gridLayer.frame = rootLayer.bounds;
	gridLayer.layoutManager = [CAConstraintLayoutManager layoutManager];
	gridLayer.autoresizingMask = kCALayerWidthSizable | kCALayerHeightSizable;
	gridLayer.borderWidth = (kDebugLayers == YES) ? 2.0f : 0.0f;
	gridLayer.borderColor = CGColorCreateGenericRGB(0.0, 1.0, 0.0, 1);
	[self constrainLayerToSuperlayer:gridLayer withScale:1.0];
	[rootLayer addSublayer:gridLayer];
	
	// Create the Cells into the GridLayer
	[self layoutCellsInGridLayer:gridLayer];
	
	// Setup the 3D transformation
	[self setupPerspectiveWithX:0 andY:0];
}

#pragma mark -
#pragma mark Core Methods

- (void)layoutCellsInGridLayer:(CALayer *)layer {
	int columns = 6;
	int rows = 6;
	
	// The spinning animation effect will be added in the createCellInParent
	// call.
	for (int row = 0; row < rows; row++) {
        for (int column = 0; column < columns; column++) {
			[self createCellInParentLayer:layer 
							 totalColumns:columns 
								totalRows:rows
							currentColumn:column 
							   currentRow:row];
		}
	}
	
	[layer layoutIfNeeded];
}

- (void)setupFlipAnimationOnLayer:(CALayer *)layer {
	float duration = (float)frandom(0.5, 5.0);
	//float duration = (float)frandom(5, 15);
	
	CABasicAnimation* animation = [CABasicAnimation animationWithKeyPath:@"transform.rotation.y"];
	animation.fromValue = [NSNumber numberWithDouble:-1.0f * M_PI];
	animation.toValue = [NSNumber numberWithDouble:1.0f * M_PI];
	animation.duration = duration;
	animation.repeatCount = 1e100f;
	animation.beginTime = CACurrentMediaTime() + frandom(0.1, 30);
	animation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
	
	[layer addAnimation:animation forKey:@"rotationY"];
}

- (void)setupPerspectiveWithX:(float)x andY:(float)y {
	CATransform3D transform = CATransform3DMakeRotation(x, 0, 1, 0); 
	transform = CATransform3DRotate(transform, y, 1, 0, 0);
	float zDistance = -450; 
	transform.m34 = 1.0 / -zDistance;
	gridLayer.sublayerTransform = transform;	
}

#pragma mark -
#pragma mark Layer Helper Methods

- (void)createCellInParentLayer:(CALayer *)parent 
				   totalColumns:(int)columns 
					  totalRows:(int)rows
				  currentColumn:(int)column
					 currentRow:(int)row {
	
	CALayer* layer = [CALayer layer];
	layer.backgroundColor = CGColorCreateGenericRGB(frandom(0.1, 0.9),
													frandom(0.1, 0.9), 
													frandom(0.1, 0.9),
													frandom(0.2, 1.0));
	layer.borderWidth = (kDebugLayers == YES) ? 2.0f : 0.0f;
	layer.borderColor =  CGColorCreateGenericRGB(0.75, 0.23, 1.0, 1.0);
	layer.contentsGravity = kCAGravityResizeAspectFill;
//	layer.contents = // Load your image here
	layer.cornerRadius = 5;
	layer.masksToBounds = YES;
	
	// Maybe throw a flip animtion on the cell?
	if ((int)arc4random() % 3 + 1 == 1)
		[self setupFlipAnimationOnLayer:layer];
	
	float scaleOfCell = 1.0;
	int offset = -2;
	
	// This is the magic, it means that we don't have to go and find the
	// MaxX or MaxY of the adjoining Cell. Using the scale: attribute
	// the Cell is placed in the correct location inside the Parent Layer.
	// Note: The offset is used to make a little gap between the Cells, this
	// is the only part I'm not 100% happy with.
	[layer addConstraint:[CAConstraint constraintWithAttribute:kCAConstraintWidth
													relativeTo:@"superlayer"
													 attribute:kCAConstraintWidth
														 scale:scaleOfCell / columns
														offset:offset * 2]];
	
	[layer addConstraint:[CAConstraint constraintWithAttribute:kCAConstraintHeight
													relativeTo:@"superlayer"
													 attribute:kCAConstraintHeight
														 scale:scaleOfCell / rows
														offset:offset * 2]];
	
	[layer addConstraint:[CAConstraint constraintWithAttribute:kCAConstraintMinX
													relativeTo:@"superlayer"
													 attribute:kCAConstraintMaxX
														 scale:column / (float)columns
														offset:abs(offset)]];
	
	[layer addConstraint:[CAConstraint constraintWithAttribute:kCAConstraintMinY
													relativeTo:@"superlayer"
													 attribute:kCAConstraintMaxY
														 scale:row / (float)rows
														offset:abs(offset)]];
	
	[parent addSublayer:layer];
}

- (void)constrainLayerToSuperlayer:(CALayer *)layer withScale:(float)scale {
	[layer addConstraint:[CAConstraint constraintWithAttribute:kCAConstraintWidth
													relativeTo:@"superlayer"
													 attribute:kCAConstraintWidth
														 scale:scale
														offset:0.0]];
	
	[layer addConstraint:[CAConstraint constraintWithAttribute:kCAConstraintHeight
													relativeTo:@"superlayer"
													 attribute:kCAConstraintHeight
														 scale:scale
														offset:0.0]];
	
	[layer addConstraint:[CAConstraint constraintWithAttribute:kCAConstraintMidY
													relativeTo:@"superlayer"
													 attribute:kCAConstraintMidY]];
	
	[layer addConstraint:[CAConstraint constraintWithAttribute:kCAConstraintMidX
													relativeTo:@"superlayer"
													 attribute:kCAConstraintMidX]];
}



@end
