/*
MyView.m
Photo Spin

Copyright 2008 Ben Clark-Robinson.

Permission is hereby granted, free of charge, to any person
obtaining a copy of this software and associated documentation
files (the "Software"), to deal in the Software without
restriction, including without limitation the rights to use,
copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the
Software is furnished to do so, subject to the following
conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.
*/

#import "MyView.h"
#import <QuartzCore/QuartzCore.h>
#import <Quartz/Quartz.h>

#define SCALE 0.45f
#define DEBUG_ANIMATION NO

@interface MyView (Private) 
	- (CGImageRef)loadImageFromBundle:(NSString *)pathForResource;
	- (CGRect) bestFitForImage:(CGImageRef)image;
@end


@implementation MyView

- (void)awakeFromNib {
	CALayer *rootLayer = [CALayer layer];
	self.layer = rootLayer;
	self.wantsLayer = YES;
	rootLayer.borderWidth = (DEBUG_ANIMATION == YES) ? 2.0f : 0.0f;
	
	CALayer *backgroundLayer = [CALayer	layer];
	backgroundLayer.name = @"backgroundLayer";
	backgroundLayer.frame = rootLayer.frame;
	backgroundLayer.contents = (id)[self loadImageFromBundle:@"ReflectionWhiteMainBackground"];
	backgroundLayer.contentsGravity = kCAGravityResizeAspectFill;
	backgroundLayer.autoresizingMask = kCALayerWidthSizable | kCALayerHeightSizable;
	[rootLayer addSublayer:backgroundLayer];
	
	CALayer *subLayer = [CALayer layer];
	subLayer.contents = (id)[self loadImageFromBundle:@"test"];
	subLayer.borderWidth = (DEBUG_ANIMATION == YES) ? 2.0f : 0.0f;
	subLayer.bounds = CGRectMake(0.0f, 0.0f,
								 NSWidth(self.bounds) * SCALE, NSHeight(self.bounds) * SCALE);
	subLayer.position = CGPointMake(NSMidX(self.bounds), NSMidY(self.bounds));
	subLayer.contentsGravity = kCAGravityResizeAspect;
	subLayer.masksToBounds = YES;
	
	/*
	// This enables a perspective transform. The value of zDistance
	// affects the sharpness of the transform.
	float zDistance = 850;
	CATransform3D sublayerTransform = CATransform3DIdentity;
	sublayerTransform.m34 = 1.0 / -zDistance;
	subLayer.transform = sublayerTransform;
	
	CABasicAnimation *flipAnimation = [CABasicAnimation animationWithKeyPath:@"transform.rotation.y"];
    flipAnimation.toValue = [NSNumber numberWithDouble:1.0f * M_PI];
	flipAnimation.autoreverses = YES;
	flipAnimation.duration = 2.0f;
	flipAnimation.repeatCount = 1e100f;
	flipAnimation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
	[subLayer addAnimation:flipAnimation forKey:@"flip"];	
	 */
	
	[backgroundLayer addSublayer:subLayer];	
}

@end

@implementation MyView (Private)

- (CGRect) bestFitForImage:(CGImageRef)image {
	CGSize size = CGSizeMake(NSWidth([self bounds]), NSHeight([self bounds]));
	CGFloat imageWidth = CGImageGetWidth(image);
	CGFloat imageHeight = CGImageGetHeight(image);
	CGFloat scale = 0.0f;
	if(size.width / imageWidth < size.height / imageHeight) {
		scale = size.width / imageWidth;
	} else {
		scale = size.height / imageHeight;
	}
	CGRect rect = {CGPointZero, {scale * imageWidth, scale * imageHeight}};
	// if we have a portrait image we want to center it on the width
	if(rect.size.width < size.width) {
		rect.origin.x = (size.width - rect.size.width)/2.0f;
	}
	return rect;
}

- (CGImageRef)loadImageFromBundle:(NSString*)pathForResource {
	CGImageRef image = NULL;
	NSBundle *bun = [NSBundle mainBundle];
	NSString *path = [bun pathForResource:pathForResource ofType:@"jpg"];
	NSURL * url = [NSURL fileURLWithPath:path];
	CGImageSourceRef imageSource = CGImageSourceCreateWithURL((CFURLRef)url, NULL);
	if(imageSource != NULL) {
		image = CGImageSourceCreateImageAtIndex(imageSource, 0, NULL);
		CFRelease(imageSource);
	} else {
		NSLog(@"Could not load image");
		return NULL;
	}
	
	if(NULL != image) {
		CGRect rect = [self bestFitForImage:image];
		CGColorSpaceRef colorSpace = CGColorSpaceCreateWithName(kCGColorSpaceGenericRGB);
		CGContextRef context = CGBitmapContextCreate(NULL, rect.size.width, 
													 rect.size.height, 8, 0, 
													 colorSpace, 
													 kCGImageAlphaPremultipliedFirst); 
		CGContextSetInterpolationQuality(context, kCGInterpolationHigh);
		rect.origin = CGPointZero;
		CGContextDrawImage(context, rect, image);
		CGContextFlush(context);
		CGImageRef scaledImage = CGBitmapContextCreateImage(context);
		CGContextRelease (context);
		CGImageRelease(image);
		image = NULL;
		image = scaledImage;
	}
	
	return image;
}


@end
