/*
 MyView.h
 Photo Spin
 
 Copyright 2008 Ben Clark-Robinson.
*/

#import <Cocoa/Cocoa.h>


@interface MyView : NSView {

}

@end
